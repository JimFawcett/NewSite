# RustDirNav

https://JimFawcett.github.io/RustDirNav.html

Directory navigator that uses generic type to specify do_file and do_dir methods
